package com.cg.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.dao.IMobiledao;
import com.cg.dao.IMobiledaoImpl;
import com.cg.exception.PMSException;

public class IMobileServiceImpl implements IMobileService {
	
	IMobiledao dao=new IMobiledaoImpl();

	@Override
	public void validateName(String custName) throws PMSException {

		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (Pattern.matches(nameRegEx, custName) == false) {
			throw new PMSException("name should contain only alphabets");
		}
	}

	@Override
	public void validateAddress(String address) throws PMSException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (Pattern.matches(nameRegEx, address) == false) {
			throw new PMSException("name should contain only alphabets");
		}
		
	}

	@Override
	public void validateCellNo(String cellno) throws PMSException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, cellno) == false) {
			throw new PMSException("mobile number should contain exactly 10 digits");
		}
		
	}

	@Override
	public void validateOrderId(int orderId) throws PMSException {
		String idRegEx = "[0-9]+";
		if (Pattern.matches(idRegEx, String.valueOf(orderId)) == false) {
			throw new PMSException("orderid should contain only digits");
		}
	}

	@Override
	public void validateCustId(int custId) throws PMSException {
		String idRegEx = "[0-9]+";
		if (Pattern.matches(idRegEx, String.valueOf(custId)) == false) {
			throw new PMSException("orderid should contain only digits");
		}
		
	}

	@Override
	public void validateModel(String MobileModel) throws PMSException {
		String pizzaRegEx = "[a-zA-Z]+";
		if (Pattern.matches(pizzaRegEx, MobileModel) == false) {
			throw new PMSException("pizza name should contain only alphabets");
		}
		
	}
	
	@Override
	public void purchaseMobile(Customer c,Mobile m) throws PMSException{
	   dao.purchaseMobile(c, m);
	}

	@Override
	public Map<Integer, Mobile> getPurchaseDetails(int orderId1) throws PMSException {
		
		return dao.getPurchaseDetails(orderId1);
	
	}
	

}
