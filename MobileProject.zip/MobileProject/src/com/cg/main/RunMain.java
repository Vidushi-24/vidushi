package com.cg.main;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import com.cg.bean.Customer;
import com.cg.bean.Mobile;
import com.cg.dao.IMobiledaoImpl;
import com.cg.exception.PMSException;
import com.cg.service.IMobileService;
import com.cg.service.IMobileServiceImpl;


public class RunMain {

	public static void main(String[] args) throws PMSException {

		Scanner scanner = null;

		IMobileService service = new IMobileServiceImpl();

		String continueChoice = "";

		do {

			System.out.println("****** Mobile purchase system ******");
			System.out.println("1.Purchase Mobile");
			System.out.println("2.Get purchase details");
			System.out.println("3.exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String custName = "";
						boolean custNameFlag = false;
					
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter customer name");
							try {
								custName = scanner.nextLine();
								service.validateName(custName);
							    custNameFlag = true;
								break;
							} catch (PMSException e) {
								custNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!custNameFlag);
						

						String address ="";
						boolean addressFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Customer address:");
							try {
								address = scanner.nextLine();
								service.validateAddress(address);
								addressFlag = true;
								break;
							} catch (PMSException e) {
								addressFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!addressFlag);
						
                        String cellno="";
                        boolean cellnoFlag=false;
                        do {
						scanner = new Scanner(System.in);
						System.out.println("Enter cell number:");
						try {
						cellno = scanner.nextLine();
						service.validateCellNo(cellno);
						cellnoFlag = true;
						break;
						}
						catch(PMSException e) {
							cellnoFlag=false;
							System.err.println(e.getMessage());
						}
                        }while (!cellnoFlag);
                        
						Customer customer = new Customer(custName, address, cellno);
	                        
	                        String MobileModel = "";
							boolean MobileModelFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter mobile model name:");
								MobileModel = scanner.nextLine();
								try {
									service.validateModel(MobileModel);
									MobileModelFlag = true;
									break;
								} catch (PMSException e) {
									MobileModelFlag = false;
									System.err.println(e.getMessage());
								}
							} while (!MobileModelFlag);
	                        
	                        Map<String, Integer> map = new TreeMap<>();
							map.put("nokia", 800);
							map.put("samsung", 1150);
							map.put("apple", 700);
							map.put("oneplus",400);

							double totalpricewithgst = 0;

							Set<String> set = map.keySet();
							for (String MobileName : set) {
								if (MobileName.equalsIgnoreCase(MobileModel)) {
									totalpricewithgst = map.get(MobileName) + 15000;
									break;
								}
							}
							System.out.println("mobile model is: "+MobileModel);
							System.out.print("Price : " + totalpricewithgst);
							Mobile mobile=new Mobile();
							mobile.setTotalpricewithGST(totalpricewithgst);
							
							    int orderId=0;
		                        boolean orderIdFlag=false;
		                        do {
								try {
								orderId=(int) (Math.random() * 1000);
								service.validateOrderId(orderId);
								orderIdFlag = true;
								break;
								}
								catch(PMSException e) {
								orderIdFlag=false;
								System.err.println(e.getMessage());
								}
		                        }while (!orderIdFlag);
		                        
		                        mobile.setOrderId(orderId);
		                        System.out.println("OrderId generated is: "+orderId);
		                        
		                        int custId=0;
		                        boolean custIdFlag=false;
		                        do {
								try {
								custId=(int) (Math.random() * 1000);
								service.validateCustId(custId);
								custIdFlag = true;
								break;
								}
								catch(PMSException e) {
								custIdFlag=false;
								System.err.println(e.getMessage());
								}
		                        }while (!custIdFlag);
		                        mobile.setCustId(custId);

								service.purchaseMobile(customer, mobile);
								
						break;
						
					case 2:
						int orderId1 = 0;
						boolean orderId1Flag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Order Id: ");
							try {
								orderId1 = scanner.nextInt();
								orderId1Flag=true;
								Map<Integer, Mobile> mobile1;

								try {
									 mobile1=service.getPurchaseDetails(orderId1);
									System.out.println(mobile1);

								} catch (PMSException e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								orderId1Flag = false;
								System.err.println("Id should be digits");
							}

						} while (!orderId1Flag);
						
						break;

					case 3:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}
