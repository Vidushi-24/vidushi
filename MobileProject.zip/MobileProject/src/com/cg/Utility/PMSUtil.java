package com.cg.Utility;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Customer;
import com.cg.bean.Mobile;

public class PMSUtil {
	
	public static Map<Integer,Mobile> mobiledetails=new HashMap<Integer,Mobile>();
	
	public static Map<Integer,Customer> customerdetails=new HashMap<Integer,Customer>();
	

	public static Map<Integer, Mobile> getMobiledetails() {
		return mobiledetails;
	}

	public static void setMobiledetails(Map<Integer, Mobile> mobiledetails) {
		PMSUtil.mobiledetails = mobiledetails;
	}

	public static Map<Integer, Customer> getCustomerdetails() {
		return customerdetails;
	}

	public static void setCustomerdetails(Map<Integer, Customer> customerdetails) {
		PMSUtil.customerdetails = customerdetails;
	}

	
}
