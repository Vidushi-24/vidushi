package com.cg.pms.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pms.dao.IprouctDaoImpl;
import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;

public class IprouctDaoImplTest {

	IprouctDaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new IprouctDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	@Test
	public void testAddProduct() {

		Product product = new Product("mouse", 5500d, 34);

		try {
			int genId = daoImpl.addProduct(product);
			assertNotNull(genId);
		} catch (PMSException e) {

		}
	}

	@Test
	public void testAddProductNull() {

		Product product = new Product("keyboard", 6500d, 10);

		try {
			int genId = daoImpl.addProduct(product);
			assertNull(genId);
		} catch (PMSException e) {

		}
	}

	@Test
	public void testGetAllProducts() {

		try {
			List<Product> list = daoImpl.getAllProducts();
			assertTrue(list.size() > 0);
		} catch (PMSException e) {

		}
	}

	@Test
	public void testGetAllProductsNotNull() {

		try {
			List<Product> list = daoImpl.getAllProducts();
			assertNotNull(list);
		} catch (PMSException e) {

		}
	}

	@Test
	public void testSearchProduct() {

		try {
			Product product = daoImpl.searchProduct(333);
			assertNotNull(product);
		} catch (PMSException e) {
		}
	}

}
