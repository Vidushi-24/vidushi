package com.paytm.service;

import com.paytm.bean.Paytm;
import com.paytm.exception.PaytmException;

public interface IPaytmService {

	boolean validateMobileNum(String mobNum) throws PaytmException;
    boolean validateRechargeType(String rechargeType) throws  PaytmException;
    boolean validateAmount(int amount) throws PaytmException;
    boolean validateName(String name) throws PaytmException;


	public abstract int Addtransaction(Paytm r); 
	public  abstract void viewAllTransactions();
	public  abstract void viewById(int id);
	public abstract  void deleteById(int id);
	public abstract  boolean updateDescription(int id,String description);
}
