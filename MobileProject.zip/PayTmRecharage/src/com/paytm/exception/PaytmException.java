package com.paytm.exception;

public class PaytmException extends Exception {
public PaytmException(String e ) {
	super(e);
}
}
