package com.cg.cms.bean;

public class Cab 
{
	private int cabId;
	private String name;
	private String mobile;
	private String pickUp;
	private String drop;
	
	public Cab() {
		super();
		
	}

	public Cab(int cabId,String name, String mobile, String pickUp, String drop) {
		super();
		this.cabId=cabId;
		this.name = name;
		this.mobile = mobile;
		this.pickUp = pickUp;
		this.drop = drop;
	}

	
	
	public int getCabId() {
		return cabId;
	}

	public void setCabId(int cabId) {
		this.cabId = cabId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPickUp() {
		return pickUp;
	}

	public void setPickUp(String pickUp) {
		this.pickUp = pickUp;
	}

	public String getDrop() {
		return drop;
	}

	public void setDrop(String drop) {
		this.drop = drop;
	}

	@Override
	public String toString() {
		return "Cab [cabId=" + cabId + ", name=" + name + ", mobile=" + mobile + ", pickUp=" + pickUp + ", drop=" + drop
				+ "]";
	}

	
	
	
	
	

}
