package com.cg.cms.service;

import java.util.ArrayList;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.cms.bean.Cab;
import com.cg.cms.dao.IUberDao;
import com.cg.cms.dao.UberDao;
import com.cg.cms.exceptions.UberException;

public class UberService implements IUberService 
{
	IUberDao dao = new UberDao();
	
	
	@Override
	public Cab getUberBook(Cab cab) throws UberException 
	{
		return dao.getUberBook(cab);
	}

	@Override
	public Cab getUberDetails() throws UberException 
	{
		
		return dao.getUberDetails();
	}

	@Override
	public void validateName(String name) throws UberException 
	{
		String nameRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(nameRegEx, name))
		{
			throw new UberException("Name must contain alphabets only");
		}
		
	}

	@Override
	public void validateMobile(String mobile) throws UberException {
		String mobileRegEx = "[7 | 8 | 9]{1}[0-9]{9}";
		if(!Pattern.matches(mobileRegEx, mobile))
		{
			throw new UberException("Mobile no must contain digits only");
		}
	}

	@Override
	public void validatePickUp(String pickUp) throws UberException {
		String pickUpRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(pickUpRegEx, pickUp))
		{
			throw new UberException("Pick Up location must contain alphabets only");
		}
	}

	@Override
	public void validateDrop(String drop) throws UberException {
		String dropRegEx = "[A-Za-z ]+";
		if(!Pattern.matches(dropRegEx, drop))
		{
			throw new UberException("Drop loca`tion must contain alphabets only");
		}
	}

	@Override
	public void setUberDetails(Cab cab) {
		// TODO Auto-generated method stub
		dao.setUberDetails(cab);
		
		
	}

	@Override
	public Cab getCabDetails(int cabId) {

		
		
		return dao.getCabDetails(cabId);
	}

	@Override
	public Map<Integer, Cab> getAllBookingDetails() {
		// TODO Auto-generated method stub
		return dao.getAllBookingDetails();
	}
	

}
