package com.cg.bean;

public class Theatre {

	private int theatreId;
	public String getCity() {
		return city;
	}
	public String getMovieName() {
		return movieName;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public int getPrice() {
		return price;
	}
	public int getTheatreId() {
		return theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	private String theatreName;
	private String city;
	private int noOfSeats;
	private String movieName;
	private int price;
	public Theatre(int theatreId, String theatreName, String city,
			int noOfSeats, String movieName, int price) {
		super();
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.city = city;
		this.noOfSeats = noOfSeats;
		this.movieName = movieName;
		this.price = price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " theatre id : {"+this.theatreId+"} theatre name : "+this.theatreName+" city: "+this.city
				+"seats : "+this.noOfSeats+" movie name: "+this.movieName
				+" price : "+this.price;
	}
	
}
