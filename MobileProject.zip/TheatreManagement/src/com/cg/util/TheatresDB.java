package com.cg.util;

import java.util.HashMap;

import com.cg.bean.Theatre;

public class TheatresDB {

static HashMap<Integer, Theatre> tList=new HashMap<>();
	static Theatre t=new  Theatre(10001, "Inox", "chennai",200, "abc", 202);
	static Theatre t1=new  Theatre(10002, "SPI", "chennai",400, "abc", 202);
	static Theatre t2=new  Theatre(10003, "AGS", "chennai",300, "abc", 202);
	
	public static HashMap<Integer, Theatre> getTheatres() {
		tList.put(t.getTheatreId(), t);
		tList.put(t1.getTheatreId(), t1);
		tList.put(t2.getTheatreId(), t2);
		return tList;
	}
	
	
}
