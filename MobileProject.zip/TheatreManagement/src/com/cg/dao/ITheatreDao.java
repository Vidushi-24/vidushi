package com.cg.dao;

import java.util.HashMap;

import com.cg.bean.Theatre;

public interface ITheatreDao {

	Theatre updateTheatre(int tid);
	//viewAllbookings
	//view booking by id
	public abstract HashMap<Integer, Theatre> viewAllTheatres();
	
}
