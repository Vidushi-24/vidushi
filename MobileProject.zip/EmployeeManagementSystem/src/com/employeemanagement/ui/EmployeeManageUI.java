package com.employeemanagement.ui;

import com.employeemanagement.bean.Employee;
import com.employeemanagement.service.*;

import java.util.Scanner;

public class EmployeeManageUI {
	static IEmployeeManagementService iemserv=null;
static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {
		
		while(true) {
		System.out.println("enter any option between 1 to 5");
		System.out
				.println(" 1.Add employee \n 2. Delete employee by id\n 3.View All Employees");
		System.out.println("4. View by id \n 5. Update  ");
		switch (scan.nextInt()) {

		case 1:
			int finalempid=addEmployee();
			System.out.println("account info is stored");
			System.out.println("ur account id is "+finalempid);
			break;
		case 2:
			deleteById();
			break;

		case 3:
			viewAllEmployees();
			break;
		case 4:
			viewById();
			break;
		case 5:
			System.out.println("enter 1 or 2");
			System.out.println("1.update password \n 2.update name");
			switch(scan.nextInt())
			{
			case 1:
				updatePassword();
				break;
			case 2:
				updateName();
				break;
			
			}
			break;
		default:
			break;

		}}


	}
	public static int addEmployee()
	{
		String empName,doj,pwd;
	
		int sal;
		System.out.println("enter the  empname");
		 empName=scan.next();
		 System.out.println("enter the date of joining");
		 doj=scan.next();
		 System.out.println("enter salary");
		 sal=scan.nextInt();
		 System.out.println("enter password");
		 pwd=scan.next();
		 
		 Employee emp=new Employee(empName, doj, pwd, sal);
		 iemserv=new TrainerServiceImpl();
			int aid=iemserv.addEmployee(emp);
			
			return aid;
	}
	

	public static void deleteById()
	{
		
	}
	public static void viewAllEmployees()
	{
		
	}
	public static void viewById()
	{
		
	}
	public static void updatePassword()
	{
		
	}
	public static void updateName()
	{
		
	}
	
	
	
	
	
}

