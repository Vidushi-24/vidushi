package com.employeemanagement.dao;

import java.util.HashMap;
import java.util.Map;

import com.employeemanagement.bean.Employee;

public class EmpManagementDaoImpl implements IEmpManagementDao {

	static Map<Integer, Object> accountlist=new HashMap<Integer, Object>();
	public int addEmployee(Employee emp) {
		accountlist.put(emp.getEmpid(),emp);
		accountlist.put(emp.getEmpid(),emp);
		
		return emp.getEmpid();
		
	}

	
	public void deleteById() {
		// TODO Auto-generated method stub
		
	}

	
	public void viewAllEmployees() {
		// TODO Auto-generated method stub
		
	}

	
	public void viewById() {
		// TODO Auto-generated method stub
		
	}

	
	public void updatePassword() {
		// TODO Auto-generated method stub
		
	}

	
	public void updateName() {
		// TODO Auto-generated method stub
		
	}

}
