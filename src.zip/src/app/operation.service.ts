import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AngularOperation } from './AngularOperation';

@Injectable({
  providedIn: 'root'
})
export class OperationService {
  

  ang: AngularOperation[]=[];
  http: HttpClient;
  constructor(http: HttpClient) {
    this.http=http;
   }

   search(id: number): AngularOperation[] {
    let result: AngularOperation[]=[];
    let s:AngularOperation
    var flag = 0;
    for(let i=0; i<this.ang.length;i++) {
      s = this.ang[i];
      if(id == s.id) {
         result.push(s);
         alert(s.id+ " "+ s.name);
         flag = 1;
      }
    }
    if(flag == 0)
      alert(id + "doesn't exists");
      return result;
  }

   addOperation(ao:AngularOperation) {
    this.ang.push(ao);
  }

  Update(data: AngularOperation){
      let id = data.id;
      
      for (let i = 0; i < this.ang.length; i++) {
        if(id == this.ang[i].id){
          this.ang[i].name=data.name;
          this.ang[i].salary=data.salary;
          this.ang[i].department=data.department;
          break;
        }
      }
  }
 

  deleteOperation(id: number) {
    let foundIndex: number = -1;
    for (let i = 0; i < this.ang.length; i++) {
      let c = this.ang[i];
      if (id == c.id) {
        foundIndex = i;
        break;
      }
    } this.ang.splice(foundIndex, 1);           //Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.
  }   
  
  getOperation(): AngularOperation[] {
    return this.ang;
  }

  fetched: boolean=false;
  fetchOperation() {
    this.http.get('./assets/Operation.json').subscribe(
      data => {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      });
    }


  convert(data: any) {
    for(let i of data)
    {
      let d=new AngularOperation(i.id,i.name,i.salary,i.department);
      this.ang.push(d);
    }
  }
}