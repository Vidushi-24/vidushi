import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';
import { DisplayComponent } from './display/display.component';
import { SearchComponent } from './search/search.component';

const routes: Routes = [
  {path: 'app-add',
component: AddComponent},
{path: 'app-display',
component: DisplayComponent},
{path: 'app-search',
component: SearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
}