import { Component, OnInit } from '@angular/core';
import { OperationService } from '../operation.service';
import { AngularOperation } from '../AngularOperation';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  service: OperationService;
  ang: AngularOperation[]=[];

  constructor() { }

  ngOnInit() {
    this.service.fetchOperation();
  }
  search(data:any){
    let id:number = data.id;
    this.ang = this.service.search(id);
  }
}
