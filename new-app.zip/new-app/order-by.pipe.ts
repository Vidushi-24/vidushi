import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(arr: any, column: string, order:boolean){
    if(column == undefined)
      return arr;
    let result:any[];
    if(order) {
      console.log(order);
      result = this.ascending(arr,column);
      console.log("!!!!!!");
      return result;
    }
  
  }
  /*descending(array: any, col: string) {
    array.sort((a:any,b:any)=> {
      if(a[col]>b[col]) 
        return -1;
      else
        return 1;
    });
    return array;
  }*/
  ascending(arr: any, column: string) {
    console.log("8");
   arr.sort((a:any,b:any)=> {
    console.log("9");  
      if(a[column]>b[column]) {
        console.log("**********");
        return 1;
       
      }
      else
      {
        return -1;
      }
    });
    console.log("**********");
    return arr;
  }
}
