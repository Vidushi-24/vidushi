import { Component, OnInit } from '@angular/core';
import { OperationService } from '../operation.service';
import { AngularOperation } from '../AngularOperation';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  service: OperationService;
  createdFlag: boolean=false;
  createOperation1: AngularOperation;
  constructor( service: OperationService) {
    this.service=service;
   }
   ang: AngularOperation[]=[];
  ngOnInit() {
    
  }
  add(data:any){
    this.createOperation1=new AngularOperation(data.id,data.name,data.salary,data.department);
    this.service.addOperation(this.createOperation1);
    this.createdFlag=true;
  }
  
}