import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {

  transform(arr: any, col: string, order:boolean){
    if(col == undefined)
      return arr;
    let l:any[];
    if(order) {
      console.log(order)
      l = this.ascending(arr,col);
    }
  }
  /*descending(array: any, col: string) {
    array.sort((a:any,b:any)=> {
      if(a[col]>b[col]) 
        return -1;
      else
        return 1;
    });
    return array;
  }*/
  ascending(arr: any, col: string) {
   arr.sort((a:any,b:any)=> {
      if(a[col]>b[col]) {
        return 1;
      }
      else
      {
        return -1;
      }
    });
    return arr;
  }
}
