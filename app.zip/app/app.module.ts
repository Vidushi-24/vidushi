import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import { NgModel } from '@angular/forms';
import { FormsModule } from "@angular/forms";
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddComponent } from './add/add.component';
import { DisplayComponent } from './display/display.component';
import { OperationService } from './operation.service';
import { SearchComponent } from './search/search.component';
import { OrderByPipe } from './order-by.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
    DisplayComponent,
    SearchComponent,
    OrderByPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    //NgModel,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [HttpClient,OperationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
