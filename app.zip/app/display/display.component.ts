import { Component, OnInit } from '@angular/core';
import { OperationService } from '../operation.service';
import { AngularOperation } from '../AngularOperation';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  service: OperationService;
  updateOperation: AngularOperation;
  updatedFlag: boolean;
  column: any="id";
  order: boolean=true;
  constructor( service: OperationService) {
    this.service=service;
   }
   ang: AngularOperation[]=[];
  ngOnInit() {
    this.service.fetchOperation();
    this.ang=this.service.getOperation();
  }
  delete(id:number){
    this.service.deleteOperation(id);
    this.ang=this.service.getOperation();
  }

  isUpdate:boolean=true;
  UpdateData(){
    this.isUpdate=!this.isUpdate;
  }

  Update(data:any)
  {
    //console.log("hello");
    this.service.Update(data);
    this.ang=this.service.getOperation();
    
  }

}
